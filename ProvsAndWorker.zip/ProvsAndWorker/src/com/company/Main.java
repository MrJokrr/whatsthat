package com.company;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Main {

    public static void main(String[] args) {

        Thread Prov1 = new Provider( 1000, "C:/Games/text1.txt" );  //here you write way to file
//        Thread Prov2 = new Provider( 2000, "C:/Games/text2.txt" );
//        Thread Prov3 = new Provider( 3000, "C:/Games/text3.txt" );


        Prov1.start();
        //Prov2.start();
        //Prov3.start();

    }

    public static class worker extends Thread {

        private String s;

        public worker(String s)
        {
            this.s = s;
        }

        public String run(String s) {
            StringBuffer hexString = new StringBuffer();
            try {
                MessageDigest md = MessageDigest.getInstance( "SHA-256" );
                md.update(s.getBytes());

                byte byteData[] = md.digest();

                for (int i=0;i<byteData.length;i++) {
                    String hex=Integer.toHexString(0xff & byteData[i]);
                    if(hex.length()==1) hexString.append('0');
                    hexString.append(hex);
                }
                }
            catch (NoSuchAlgorithmException e1) {
                e1.printStackTrace();
            }
            return hexString.toString();
        }
    }
}

