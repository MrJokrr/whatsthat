package com.company;

import java.io.*;

public class Provider extends Thread {

    Main.worker Worker;
    private String way;
    public String ffile = "";
    private int b = 0;
    private int delay;
    public FileInputStream fis = null;
    public FileWriter fr = null;

    public Provider(int d, String s) {
        delay = d;
        way = s;
    }

    @Override
    public void run() {
        try {
            fis = new FileInputStream( way );
            while ((b = fis.read()) != -1) {
                ffile = ffile + ((char) b);
            }
            Thread.sleep( delay );
            fr = new FileWriter( way, true );
            fr.write( Worker.run( ffile ) );
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
//        catch (Exception e)
//        {e.printStackTrace();}
        finally {
            try {
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
